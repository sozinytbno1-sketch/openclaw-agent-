/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.girlkun.models.boss.list_boss.BossNgoc;

import com.girlkun.models.boss.Boss;
import com.girlkun.models.boss.BossID;
import com.girlkun.models.boss.BossStatus;
import com.girlkun.models.boss.BossesData;
import com.girlkun.models.item.Item;
import com.girlkun.models.map.ItemMap;
import com.girlkun.models.player.Player;
import com.girlkun.services.EffectSkillService;
import com.girlkun.services.Service;
import com.girlkun.utils.Util;

/**
 * @@Edit by ndq
 */
public class BossNGOC2 extends Boss {

    public BossNGOC2() throws Exception {
        super(BossID.BOSS_NGOC2, BossesData.BOSS_NGOC2);
    }

    @Override
    public void reward(Player plKill) {
        plKill.inventory.event++;
        int randHN = Util.nextInt(1_000_000, 20_000_000);
        
        // Rơi HN
//        ItemMap it = new ItemMap(this.zone, 861, randHN, this.location.x, this.zone.map.yPhysicInTop(this.location.x,
//                this.location.y - 24), plKill.id);
//        it.options.add(new Item.ItemOption(30, 0));
//        Service.getInstance().dropItemMap(this.zone, it);
        
        // Cộng Thẳng Vào Túi
        plKill.getMaster().inventory.ruby += randHN;
        Service.gI().sendMoney(plKill);
        Service.getInstance().sendThongBao(plKill, "Bạn đã nhận được " + Util.powerToStringnew(randHN) + " Hồng Ngọc");
        
        int a = 0;
        for (int i = 0; i < 8; i++) {
            ItemMap it1 = new ItemMap(this.zone, 1464, 1, this.location.x + a, this.zone.map.yPhysicInTop(this.location.x,
                    this.location.y - 24), plKill.id);
            Service.getInstance().dropItemMap(this.zone, it1);
            a += 10;
        }
        ItemMap it1 = new ItemMap(this.zone, 1457, 1, this.location.x - 10, this.zone.map.yPhysicInTop(this.location.x,
                this.location.y - 24), plKill.id);
        Service.getInstance().dropItemMap(this.zone, it1);
    }

    @Override
    public void active() {
        super.active(); //To change body of generated methods, choose Tools | Templates.
        if (Util.canDoWithTime(st, 2500000)) {
            this.changeStatus(BossStatus.LEAVE_MAP);
        }
    }

    @Override
    public void joinMap() {
        super.joinMap(); //To change body of generated methods, choose Tools | Templates.
        st = System.currentTimeMillis();
    }
    private long st;

    @Override
    public double injured(Player plAtt, double damage, boolean piercing, boolean isMobAttack) {
        if (!this.isDie()) {
            if (!piercing && Util.isTrue(this.nPoint.tlNeDon - plAtt.nPoint.tlchinhxac, 1000)) {
                this.chat("Xí hụt");
                return 0;
            }
            damage = this.nPoint.subDameInjureWithDeff(damage);
            if (!piercing && effectSkill.isShielding) {
                if (damage > nPoint.hpMax) {
                    EffectSkillService.gI().breakShield(this);
                }
                damage = 1;
            }
            this.nPoint.subHP(damage);
            if (isDie()) {
                this.setDie(plAtt);
                die(plAtt);
            }
            return damage;
        } else {
            return 0;
        }
    }
}

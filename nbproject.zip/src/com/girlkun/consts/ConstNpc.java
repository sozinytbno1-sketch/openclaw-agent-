package com.girlkun.consts;

public class ConstNpc {

    public static final String CALICK_KE_CHUYEN = "20 năm trước bọn Android sát thủ đã đánh bại nhóm bảo vệ trái đất của Sôngoku và Cađíc, Pôcôlô ...\n"
            + "Riêng Sôngoku vì bệnh tim nên đã chết trước đó nên không thể tham gia trận đánh...\n"
            + "Từ đó đến nay bọn chúng tàn phá Trái Đất không hề thương tiếc\n"
            + "Cháu và mẹ may mắn sống sót nhờ lẩn trốn tại tần hầm của công ty Capsule...\n"
            + "Cháu tuy cũng là siêu xayda nhưng cũng không thể làm gì được bọn Android sát thủ...\n"
            + "Chỉ có Sôngoku mới có thể đánh bại bọn chúng\n"
            + "mẹ cháu đã chế tạo thành công cỗ máy thời gian\n"
            + "và cháu quay về quá khứ để cứu Sôngoku...\n"
            + "Bệnh của Gôku ở quá khứ là nan y, nhưng với trình độ y học tương lai chỉ cần uống thuốc là khỏi...\n"
            + "Hãy đi theo cháu đến tương lai giúp nhóm của Gôku đánh bạn bọn Android sát thủ\n"
            + "Khi nào chú cần sự giúp đỡ của cháu hãy đến đây nhé";

    public static final String HUONG_DAN_DOANH_TRAI = "1) Trại độc nhãn là nơi các ngươi không nên vào vì những tướng tá rất mạnh. Hahaha\n"
            + "2) Trong trại độc nhãn, mỗi vị tướng đều giữ ngọc rồng từ 1 sao đến 2 sao, tùy lúc\n"
            + "3) Nếu ngươi thích chết thì cứ việc vào. Nhưng ta chỉ cho vào mỗi ngày một lần thôi, để ngươi khỏi phải chết nhiều, hahaha.\n"
            + "4) Các vị tướng trong trại rất mạnh nhé, các ngươi không đơn giản có thể đánh bại họ bằng cách bình thường như đánh quái được đâu\n"
            + "5) Muốn vào, ngươi phải đi cùng một người đồng đội cùng bang (phải đứng gần ngươi). Nhưng ta khuyên là nên đi 3-4 người cùng.\n"
            + "6) Mỗi lần vào, ngươi chỉ có 30 phút để đánh. Sau 30 phút mà ngươi vẫn không thắng, ta sẽ cho máy bay chở ngươi về nhà.";

    public static final String HUONG_DAN_BLACK_BALL_WAR = "Mỗi ngày từ 20h đến 21h các hành tinh có Ngọc Rồng Sao Đen sẽ xảy ra 1 cuộc đại chiến\n"
            + "Người nào tìm thấy và giữ được Ngọc Rồng Sao Đen sẽ mang phần thưởng về cho bang của mình trong vòng 1 ngày\n"
            + "Lưu ý mỗi bang có thể chiếm hữu nhiều viên khác nhau nhưng nếu cùng loại cũng chỉ nhận được 1 lần phần thưởng đó. Có 2 cách để thắng:\n"
            + "1) Giữ ngọc sao đen trên người hơn 5 phút liên tục\n"
            + "2)Sau 30 phút tham gia tàu sẽ đón về và đang giữ ngọc sao đen trên người";
    public static final String HUONG_DAN_MAP_MA_BU = "Mỗi ngày từ 12h đến 13h tại đại hội võ thuật sẽ xảy ra 1 cuộc đại chiến\n"
            + "Người nào đánh bại các boss ở map sẽ nhận được những món đồ giá trị\n"
            + "Lưu ý khi vào map sẽ chia làm 2 phe riêng biệt\n"
            + "Cố gắng tồn tại và chiến đấu đến Boss cuối cùng\n"
            + "Càng vào sâu trong map sẽ có những vật phẩm đặc biệt";
    public static final String HUONG_DAN_DOI_SKH_VIP = "Nguyên liệu cần để làm SKH VIP là :\n"
            + "1 món Hủy diệt + 2 món SKH thường và 1 đá ngũ sắc\n"
            + "Lưu ý SKH VIP sẽ tạo ra dựa vào món Hủy diệt\n"
            + "Ví dụ nguyên liệu gồm : Quần Xayda Hủy diệt + 2 món SKH thường ngẫu nhiên + 1 Đá ngũ sắc\n"
            + "Bạn sẽ nhận lại được Quần Xayda với chỉ số SKH VIP";
    public static final String HUONG_DAN_DO_TS = "Nguyên liệu cần để làm Dồ Thiên sứ là :\n"
            + "1 Công thức theo Hành tinh mong muốn + 1 Đá cầu vòng + 999 Mảnh thiên sứ\n"
            + "Lưu ý: Đồ thiên sứ sẽ ra hảnh tinh theo Thông tin của Công thức";
    public static final String HUONG_DAN_CAY_CHAY = "Cách chơi game cho người mới :\n"
            + "1) Người mới nên nhập hết code và xem hết gim ở thông báo trong nhóm\n"
            + "2) Người cày chay không nạp thì càng nên tới NPC ma bư gắp thú vip để có cải trang xịn có tnsm cao dễ chơi\n"
            + "3) Cày chay chuyển sinh 30 và mở giới hạn đến 5000 tỷ là được\n"
            + "4) Sức đánh đấm quái quá to hoặc quá nhỏ sẽ không nhận tiềm năng nên chú ý canh sức đánh hành trang tầm 2 triệu"
            + "5) Đệ tử cộng tiềm năng do chỉ số chậm để tránh lỗi, chát:tt để biết chi tiết \n"
            + "6) Để auto cộng chỉ số , chát:chiso để cộng nhanh \n"
            + "7) SEVER X50-X200 NẠP COIN nên anh em chú ý lúc khuyến mãi\n"
            + "Lưu ý:nạp ib admin 0355368614 (zalo) ";
    public static final String HUONG_DAN_DAI_GIA = "Cách chơi game cho người mới đại gia :\n"
            + "1) Người mới nên nhập hết code và xem hết gim ở thông báo trong nhóm\n"
            + "2) ĐẠI GIA nạp 200k mua cải trang 500% hoặc nạp 500k mua cải trang 1000% để tàn sát boss vừa được tính điểm top nạp\n"
            + "3) ĐẠI GIA nên chuyển sinh 30 và mở giới hạn đến 10000 tỷ. Ngoài ra nên có 1 con chiến thần cấp 10 để fam hồng ngọc để mua đá tu tiên \n"
            + "4) Đệ tử cộng tiềm năng do chỉ số chậm để tránh lỗi, chát:tt để biết chi tiết \n"
            + "5) Để biết thông tin chiến thần , chát:th để biết chi tiết \n"
            + "6) Để auto cộng chỉ số , chát:chiso để cộng nhanh \n"
            + "7) SEVER X50-X200 NẠP COIN nên đại gia chú ý lúc khuyến mãi\n"
            + "8) ADMIN có bán cấp độ chiến thần, cấp độ tu tiên nhân vật và các vật phẩm có số liệu x999 trong shop thần mèo\n"
            + "Lưu ý:nạp ib admin 0355368614 (zalo) ";
    public static final String THONG_TIN_DE_TU = "Bảng xếp hạn sức mạnh các loại đệ :\n"
            + "1) Đệ NAKAROT  120% chỉ số khi hợp thể (chỉ có ở đua top nạp hoặc mua AD với giá 200k ATM) \n"
            + "2) Đệ GOGETA   80% chỉ số khi hợp thể ( đua top nạp,pvp chiến trường, đổi điểm pvp hoặc 100k ATM) \n"
            + "3) Đệ GOKU SS4 60% chỉ số khi hơp thể ( tham gia pvp chiến trường đổi điểm hoặc 50k ATM ) \n"
            + "4) Đệ ZENO     50% chỉ số khi hơp thể ( gắp vip, mua trong shop ) \n"
            + "5) Đệ BROLY    40% chỉ số khi hơp thể ( nhập code, gắp vip, mua trong shop, săn boss broly chiến trường) \n"
            + "6) Đệ Berrus   15% chỉ số khi hơp thể ( mua trong shop, săn boss GOJO sân sau siêu thị, nhập code) \n"
            + "7) Đệ Ma bư    5% chỉ số khi hơp thể  ( săn bosss ma bư kiếm trứng ma bư và ấp trứng ) \n"
            + "8) ADMIN có bán đệ tử vip các loại\n"
            + "Lưu ý:mua ib admin 0355368614 (zalo) ";
    public static final String HUONG_DAN_SU_KIEN = "Cách chơi sự kiện 1 tháng 6 :\n"
            + "1) Tìm trứng các loại đệ tử ở gắp thú hoặc săn boss \n"
            + "2) Tìm nguyên liệu sự kiện ở vách núi đen \n"
            + "3) Đổi nguyên liệu nhận được hộp thánh tôn \n"
            + "Lưu ý:mua ib admin 0355368614 (zalo) ";
    //npcid
    public static final byte ONG_GOHAN = 0;
    public static final byte ONG_PARAGUS = 1;
    public static final byte ONG_MOORI = 2;
    public static final byte RUONG_DO = 3;
    public static final byte DAU_THAN = 4;
    public static final byte CON_MEO = 5;
    public static final byte KHU_VUC = 6;
    public static final byte BUNMA = 7; //562
    public static final byte DENDE = 8; //350
    public static final byte APPULE = 9; //565
    public static final byte DR_DRIEF = 10;
    public static final byte CARGO = 11;
    public static final byte CUI = 12;
    public static final byte QUY_LAO_KAME = 13;
    public static final byte TRUONG_LAO_GURU = 14;
    public static final byte VUA_VEGETA = 15;
    public static final byte URON = 16;
    public static final byte BO_MONG = 17;
    public static final byte THAN_MEO_KARIN = 18;
    public static final byte THUONG_DE = 19;
    public static final byte THAN_VU_TRU = 20;
    public static final byte BA_HAT_MIT = 21; //1410
    public static final byte TRONG_TAI = 22;
    public static final byte GHI_DANH = 23;
    public static final byte RONG_THIENG = 24;
    public static final byte LINH_CANH = 25;
    public static final byte DOC_NHAN = 26;
    public static final byte RONG_THIENG_NAMEC = 27;
    public static final byte CUA_HANG_KY_GUI = 28;
    public static final byte RONG_OMEGA = 29;
    public static final byte RONG_2S = 30;
    public static final byte RONG_3S = 31;
    public static final byte RONG_4S = 32;
    public static final byte RONG_5S = 33;
    public static final byte RONG_6S = 34;
    public static final byte RONG_7S = 35;
    public static final byte RONG_1S = 36;
    public static final byte BUNMA_TL = 37;
    public static final byte CALICK = 38;
    public static final byte SANTA = 39;
    public static final byte MABU_MAP = 40;
    public static final byte TRUNG_THU = 41;
    public static final byte QUOC_VUONG = 42;
    public static final byte TO_SU_KAIO = 43;
    public static final byte OSIN = 44;
    public static final byte KIBIT = 45;
    public static final byte BABIDAY = 46;
    public static final byte GIUMA_DAU_BO = 47;
    public static final byte NGO_KHONG = 48;
    public static final byte DUONG_TANG = 49;
    public static final byte QUA_TRUNG = 50;
    public static final byte DUA_HAU = 51;
    public static final byte HUNG_VUONG = 52;
    public static final byte TAPION = 53;
    public static final byte LY_TIEU_NUONG = 54;
    public static final byte BILL = 55;
    public static final byte WHIS = 56;
    public static final byte CHAMPA = 57;
    public static final byte VADOS = 58;
    public static final byte TRONG_TAI_ = 59;
    public static final byte GOKU_SSJ = 60;
    public static final byte GOKU_SSJ_ = 61;
    public static final byte POTAGE = 62;
    public static final byte JACO = 63;
    public static final byte NPC_64 = 64;
    public static final byte YARIROBE = 65;
    ///
    // public static final byte ZENOSAMA = 85;
    ///
    public static final byte NOI_BANH = 66;
    public static final byte MR_POPO = 67;
    public static final byte PANCHY = 68;
    public static final byte THO_DAI_CA = 69;
    public static final byte FIDE = 73;
    public static final byte Jiren = 75;
    public static final byte NPC_CHUYENSINH = 76;
    public static final byte UUB = 77;
    public static final byte ZAMASU = 79;
    public static final byte MEO_THAN_TAI = 80;
    public static final byte MI_NUONG = 82;
    public static final byte CHIEN_THAN = 83;
    public static final byte TRUNG_LINH_THU = 97;
    public static final byte ONG_GIA_NOEL = 98;
    public static final byte CAY_THONG_NOEL = 78;
    public static final byte Monaito = 102;
    public static final byte RUT_VANG = 103;
    public static final byte RONG_XUONG = 84;
    public static final byte CAUCA = 86;
    public static final byte NPC_GAP_THU = 87;
    public static final byte CHIEN_TRUONG = 88;
    public static final byte MEDUSA = 89;
    public static final byte NPC_KETHON = 90;
    public static final byte RONG_SIEU_CAP = 91;
    public static final byte GOKU = 92;
    public static final byte CAYNEU = 93;
    public static final byte GOKUTET = 94;
    public static final byte NPC_KICHDUC = 96;

    //----------------------index menu------------------------------------------
    //menu o len tang map mabu
    public static final int GO_UPSTAIRS_MENU = 10000;

    //index menu base
    public static final int IGNORE_MENU = 712002;
    public static final int BASE_MENU = 752002;

    public static final int DOI_TIEN = 555;
    public static final int MENU_DOITIEN1 = 556;
    public static final int MENU_DOITIEN2 = 557;

    //index quy lão kamê
    public static final int MENU_ACCPET_GO_TO_BDKB = 500;
    public static final int MENU_OPEN_BDKB = 501;
    public static final int MENU_OPENED_BDKB = 502;
    public static final int QUY_DOI_HN = 503;
    public static final int QUY_DOI_TV = 504;
    public static final int MENU_EVENT = 523;
    public static final int MENU_GIAO_BONG = 524;
    public static final int CONFIRM_DOI_THUONG_SU_KIEN = 525;
    public static final int MENU_ACCPET_GO_TO_GAS = 538;
    public static final int MENU_OPEN_GAS = 539;
    public static final int MENU_OPENED_GAS = 540;
    //index than vu tru
    public static final int MENU_DI_CHUYEN = 500;

    //index menu ba hat mit
    public static final int MENU_PHA_LE_HOA_TRANG_BI = 500;
    public static final int MENU_CHUYEN_HOA_TRANG_BI = 501;
    public static final int MENU_OPTION_SHOP_BUA = 502;
    public static final int MENU_START_COMBINE = 503;
    public static final int MENU_PHAN_RA_DO_THAN_LINH = 504;
    public static final int MENU_NANG_CAP_DO_TS = 505;
    public static final int MENU_NANG_DOI_SKH_VIP = 506;
    public static final int MENU_CHUYEN_HOA_DO_HUY_DIET = 507;
    public static final int MENU_RANDOM_SKH = 508;

    //index menu linh canh
    public static final int MENU_JOIN_DOANH_TRAI = 502;

    //index menu con meo
    public static final int MAKE_MATCH_PVP = 502;
    public static final int MAKE_FRIEND = 503;
    public static final int REVENGE = 504;
    public static final int TUTORIAL_SUMMON_DRAGON = 505;
    public static final int SUMMON_SHENRON = 506;
    public static final int INTRINSIC = 507;
    public static final int CONFIRM_OPEN_INTRINSIC = 508;
    public static final int CONFIRM_OPEN_INTRINSIC_VIP = 509;
    public static final int CONFIRM_LEAVE_CLAN = 510;
    public static final int CONFIRM_NHUONG_PC = 511;
    public static final int MENU_ADMIN = 512;
    public static final int BAN_PLAYER = 513;
    public static final int BUFF_PET = 514;
    public static final int CONFIRM_REMOVE_ALL_ITEM_LUCKY_ROUND = 515;
    public static final int MENU_FIND_PLAYER = 516;
    public static final int CONFIRM_DISSOLUTION_CLAN = 517;
    public static final int CONFIRM_ACTIVE = 518;
    public static final int menutd = 519;
    public static final int menunm = 520;
    public static final int menuxd = 521;
    public static final int KETHON_PLAYER = 1125;
    public static final int MENU_USER_TAB_PET = 5266;

    //
    public static final int menusetsencon = 600;
    //
    public static final int CONFIRM_TELE_NAMEC = 522;
    public static final int MINI_GAME = 532;
    public static final int UP_TOP_ITEM = 527;
    public static final int NpcThanThu = 528;
    public static final int INFO_ALL = 529;
    public static final int CHISODO = 530;
    public static final int DOT_PHA_THANTHU = 531;
    public static final int TAIXIU = 533;
    public static final int INFO_DAO_LU = 535;
    public static final int DAO_LU_THANG_TINH = 536;
    public static final int DAO_LU_THANG_BAC = 537;
    public static final int DAO_LU_IGNORE = 538;
    public static final int DAO_LU_THANG_DAU_DE = 539;
    public static final int CHUYEN_SINH = 540;
    public static final int BAN_NHIEU_THOI_VANG = 5701;
    public static final int MUA_NHIEU = 5702;
    public static final int CHISO_NHANH = 5703;
    public static final int TUTORIAL_RONG_XUONG = 5704;
    public static final int RONG_HALLOWEN = 5705;
    public static final int TUTORIAL_RONG_SUPER = 5706;
    public static final int RONG_SUPER = 5707;

    public static final int MENU_OPTION_USE_ITEM2000 = 2000;
    public static final int MENU_OPTION_USE_ITEM2001 = 2001;
    public static final int MENU_OPTION_USE_ITEM2002 = 2002;
    public static final int MENU_OPTION_USE_ITEM2003 = 2003;
    public static final int MENU_OPTION_USE_ITEM2004 = 2004;
    public static final int MENU_OPTION_USE_ITEM2005 = 2005;
    public static final int MENU_OPTION_USE_ITEM736 = 736;
    public static final int MENU_OPTION_USE_ITEM1105 = 1105;
    public static final int MENU_OPTION_USE_ITEM1394 = 1394;
    public static final int MENU_OPTION_USE_ITEM1524 = 1524;
    public static final int MENU_OPTION_USE_ITEM1532 = 1532;

    //index menu rong thieng
//    public static final int SHENRON_NM = 507;
    public static final int SHENRON_CONFIRM = 501;
    public static final int SHENRON_1_1 = 502;
    public static final int SHENRON_1_2 = 503;
    public static final int SHENRON_2 = 504;
//    public static final int SHENRON_3 = 505;
    public static final int NAMEC_1 = 506;

    //index menu rong xuong
    public static final int HALLOWEN_CONFIRM = 507;
    public static final int HALLOWEN_1_1 = 508;
//    public static final int HALLOWEN_1_2 = 509;

    //index menu rong sieu cap
    public static final int SUPER_CONFIRM = 509;
    public static final int SUPER_1 = 510;
//    public static final int HALLOWEN_1_2 = 509;
    //index menu magic tree
    public static final int MAGIC_TREE_NON_UPGRADE_LEFT_PEA = 501;
    public static final int MAGIC_TREE_NON_UPGRADE_FULL_PEA = 502;
    public static final int MAGIC_TREE_CONFIRM_UPGRADE = 503;
    public static final int MAGIC_TREE_UPGRADE = 504;
    public static final int MAGIC_TREE_CONFIRM_UNUPGRADE = 505;

    //index menu mabu egg
    public static final int CAN_NOT_OPEN_EGG = 500;
    public static final int CAN_OPEN_EGG = 501;
    public static final int CONFIRM_OPEN_EGG = 502;
    public static final int CONFIRM_DESTROY_EGG = 503;
    //index menu mabu egg
    public static final int CAN_NOT_OPEN_DUA = 500;
    public static final int CAN_OPEN_DUA = 501;
    public static final int CONFIRM_OPEN_DUA = 502;
    public static final int CONFIRM_DESTROY_DUA = 503;

    //index menu npc nhà
    public static final int QUA_TAN_THU = 500;
    public static final int MENU_PHAN_THUONG = 501;
    public static final int NAP_THE = 502;

    //index menu quốc vương
    public static final int OPEN_POWER_MYSEFT = 500;
    public static final int OPEN_POWER_PET = 501;

    //index menu thượng đế
    public static final int MENU_CHOOSE_LUCKY_ROUND = 500;

    //index menu cui
    public static final int MENU_FIND_KUKU = 501;
    public static final int MENU_FIND_MAP_DAU_DINH = 502;
    public static final int MENU_FIND_RAMBO = 503;

    //index menu rồng omega
    public static final int MENU_NOT_OPEN_BDW = 500;
    public static final int MENU_OPEN_BDW = 501;
    public static final int MENU_REWARD_BDW = 502;
    //index menu osin
    public static final int MENU_NOT_OPEN_MMB = 500;
    public static final int MENU_OPEN_MMB = 501;
    public static final int MENU_REWARD_MMB = 502;

    //index menu rồng sao đen
    public static final int MENU_PHU_HP = 500;
    public static final int MENU_OPTION_PHU_HP = 501;
    public static final int MENU_OPTION_GO_HOME = 502;

    //index menu bò mộng;
    public static final int MENU_OPTION_LEVEL_SIDE_TASK = 500;
    public static final int MENU_OPTION_PAY_SIDE_TASK = 501;

    //------------------------------shop id-------------------------------------
    //npcname_shoporder
    public static final int SHOP_BUNMA_QK_0 = 500;
    public static final int SHOP_DENDE_0 = 501;
    public static final int SHOP_APPULE_0 = 502;
    public static final int SHOP_SANTA_0 = 503;
    public static final int SHOP_SANTA_1 = 504;
    public static final int SHOP_URON_0 = 505;
    public static final int SHOP_BA_HAT_MIT_0 = 506;
    public static final int SHOP_BA_HAT_MIT_1 = 507;
    public static final int SHOP_BA_HAT_MIT_2 = 508;
    public static final int SIDE_BOX_LUCKY_ROUND = 509;
    public static final int SHOP_BUNMA_TL_0 = 510;
    public static final int SIDE_BOX_ITEM_REWARD = 511;

    public static final int RUONG_GO = 512;
    public static final int SHOP_YARIROBE = 513;
    public static final int SHOP_ONG_GIA_NOEL = 514;
    public static final int SHOP_GOKU = 515;
    public static final int SHOP_GOKUTET = 515;

    //------------------------------One Piece-------------------------------------
    public static final int BROOK = 122;
    public static final int CHOPPER = 120;
    public static final int FRANKY = 121;
    public static final int USOPP = 119;
    public static final int NICO_ROBIN = 118;
    public static final int NAMI = 117;
    public static final int SANJI = 116;
    public static final int RORONOA_ZORO = 115;
    public static final int LUFFY = 114;

}

/**
 * Code được viết bởi NDQ Vui lòng không sao chép mã nguồn này dưới mọi hình
 * thức.
 */

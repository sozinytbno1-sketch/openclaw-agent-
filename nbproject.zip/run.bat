@echo off
chcp 65001 > nul
set JAVA_HOME=C:\Program Files\Eclipse Adoptium\jdk-21.0.11.10-hotspot
set PATH=%JAVA_HOME%\bin;%PATH%
cd /d "%~dp0"
java -cp "lib\*;dist\Arriety_MEDUSA.jar" com.girlkun.server.ServerManager
pause
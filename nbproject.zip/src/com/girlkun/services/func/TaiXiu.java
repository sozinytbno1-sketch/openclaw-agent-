/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.girlkun.services.func;

import com.girlkun.database.GirlkunDB;
import com.girlkun.models.item.Item;
import com.girlkun.models.player.Player;
import com.girlkun.server.Client;
import com.girlkun.services.ChatGlobalService;
import com.girlkun.services.InventoryServiceNew;
import com.girlkun.services.ItemService;
import com.girlkun.services.Service;
import com.girlkun.utils.Logger;
import com.girlkun.utils.Util;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 *
 * @author DEV Ăn Trộm
 */
public class TaiXiu implements Runnable {

    public int goldTai;
    public int goldXiu;
    public boolean ketquaTai = false;
    public boolean ketquaXiu = false;
    public boolean ketquaTamhoa = false;

    public static int MIN_HN = 1_000_000;
    public static int MAX_HN = 100_000_000;
    public static int TILE_AN_THUA = 80;

    public boolean baotri = false;
    public long lastTimeEnd;
    public List<Player> PlayersTai = new ArrayList<>();
    public List<Player> PlayersXiu = new ArrayList<>();
    private static TaiXiu instance;
    public int x, y, z;

    public static TaiXiu gI() {
        if (instance == null) {
            instance = new TaiXiu();
        }
        return instance;
    }

    public void addPlayerXiu(Player pl) {
        if (!PlayersXiu.equals(pl)) {
            PlayersXiu.add(pl);
        }
    }

    public void addPlayerTai(Player pl) {
        if (!PlayersTai.equals(pl)) {
            PlayersTai.add(pl);
        }
    }

    public void removePlayerXiu(Player pl) {
        if (PlayersXiu.equals(pl)) {
            PlayersXiu.remove(pl);
        }
    }

    public void removePlayerTai(Player pl) {
        if (PlayersTai.equals(pl)) {
            PlayersTai.remove(pl);
        }
    }

    @Override
    public void run() {
        while (true) {
            try {
                if (((TaiXiu.gI().lastTimeEnd - System.currentTimeMillis()) / 1000) <= 0) {
                    int x, y, z;
                    // Thực hiện các hành động sau khi chờ 10 giây
                    if (TaiXiu.gI().goldTai >= TaiXiu.gI().goldXiu) {
                        if (Util.isTrue(60, 100)) {
                            x = Util.nextInt(1, 2);
                            y = Util.nextInt(1, 3);
                            z = Util.nextInt(1, 3);
                            TaiXiu.gI().x = x;
                            TaiXiu.gI().y = y;
                            TaiXiu.gI().z = z;
                        } else {
                            x = Util.nextInt(3, 6);
                            y = Util.nextInt(4, 6);
                            z = Util.nextInt(4, 6);
                            TaiXiu.gI().x = x;
                            TaiXiu.gI().y = y;
                            TaiXiu.gI().z = z;
                        }
                    } else {
                        if (Util.isTrue(60, 100)) {
                            x = Util.nextInt(3, 6);
                            y = Util.nextInt(4, 6);
                            z = Util.nextInt(4, 6);
                            TaiXiu.gI().x = x;
                            TaiXiu.gI().y = y;
                            TaiXiu.gI().z = z;
                        } else {
                            x = Util.nextInt(1, 2);
                            y = Util.nextInt(1, 3);
                            z = Util.nextInt(1, 3);
                            TaiXiu.gI().x = x;
                            TaiXiu.gI().y = y;
                            TaiXiu.gI().z = z;
                        }
                    }
                    int tong = (x + y + z);

                    if (tong > 3 && tong < 11) {
                        ketquaTamhoa = false;
                        ketquaXiu = true;
                        ketquaTai = false;
                    }
                    if (tong > 10) {
                        ketquaTamhoa = false;
                        ketquaXiu = false;
                        ketquaTai = true;
                    }
                    if (x == y && y == z && z == x) {
                        ketquaTamhoa = true;
                        ketquaXiu = false;
                        ketquaTai = false;
                    }

                    if (ketquaTai == true) {
                        if (!TaiXiu.gI().PlayersTai.isEmpty()) {
                            for (int i = 0; i < PlayersTai.size(); i++) {
                                Player pl = this.PlayersTai.get(i);
                                if (pl != null && Client.gI().getPlayer(pl.name) != null) {
                                    int goldC = pl.goldTai + (pl.goldTai / 100 * TILE_AN_THUA);
                                    Service.getInstance().sendThongBao(pl, "Số hệ thống quay ra\n" + x + " : "
                                            + y + " : " + z + "\n|5|Tổng là : " + tong + "\n(TÀI)\n\n|1|Bạn đã chiến thắng!!");
                                    Service.getInstance().sendThongBao(pl, "Chúc mừng bạn đã dành chiến thắng và nhận được " + Util.format(goldC) + " Hồng ngọc");
                                    Logger.logTaiXiu(pl, 0, pl.goldTai, goldC);
                                    pl.inventory.ruby += goldC;
                                    pl.taixiu.win += pl.goldTai * TILE_AN_THUA / 100;
                                    Service.getInstance().sendMoney(pl);
                                    InventoryServiceNew.gI().sendItemBags(pl);
                                }
                            }
                        }
                        for (int i = 0; i < PlayersXiu.size(); i++) {
                            Player pl = this.PlayersXiu.get(i);
                            if (pl != null && Client.gI().getPlayer(pl.name) != null) {
                                Service.getInstance().sendThongBao(pl, "Số hệ thống quay ra\n" + x + " : "
                                        + y + " : " + z + "\n|5|Tổng là : " + tong + "\n(TÀI)\n\n|7|Trắng tay gòi, chơi lại đi!!!");
                                Logger.logTaiXiu(pl, 2, pl.goldXiu, 0);
                            }
                        }
                    } else if (ketquaXiu == true) {
                        if (!TaiXiu.gI().PlayersXiu.isEmpty()) {
                            for (int i = 0; i < PlayersXiu.size(); i++) {
                                Player pl = this.PlayersXiu.get(i);
                                if (pl != null && Client.gI().getPlayer(pl.name) != null) {
                                    int goldC = pl.goldXiu + (pl.goldXiu / 100 * TILE_AN_THUA);
                                    Service.getInstance().sendThongBao(pl, "Số hệ thống quay ra\n" + x + " : "
                                            + y + " : " + z + "\n|5|Tổng là : " + tong + "\n(XỈU)\n\n|1|Bạn đã chiến thắng!!");
                                    Service.getInstance().sendThongBao(pl, "Chúc mừng bạn đã dành chiến thắng và nhận được " + Util.format(goldC) + " Hồng ngọc");
                                    Logger.logTaiXiu(pl, 1, pl.goldXiu, goldC);
                                    pl.inventory.ruby += goldC;
                                    pl.taixiu.win += pl.goldXiu * TILE_AN_THUA / 100;
                                    Service.getInstance().sendMoney(pl);
                                    InventoryServiceNew.gI().sendItemBags(pl);
                                }
                            }
                        }
                        for (int i = 0; i < PlayersTai.size(); i++) {
                            Player pl = this.PlayersTai.get(i);
                            if (pl != null && Client.gI().getPlayer(pl.name) != null) {
                                Service.getInstance().sendThongBao(pl, "Số hệ thống quay ra\n" + x + " : "
                                        + y + " : " + z + "\n|5|Tổng là : " + tong + "\n(XỈU)\n\n|7|Trắng tay gòi, chơi lại đi!!!");
                                Logger.logTaiXiu(pl, 3, pl.goldTai, 0);
                            }
                        }
                    } else {
                        for (int i = 0; i < PlayersTai.size(); i++) {
                            Player pl = this.PlayersTai.get(i);
                            if (pl != null && Client.gI().getPlayer(pl.name) != null) {
                                Service.getInstance().sendThongBao(pl, "Số hệ thống quay ra\n" + x + " : "
                                        + y + " : " + z + "\n|5|Tổng là : " + tong + "\n(TAM HOA)\n\n|7|Hahaha Nhà cái lụm hết nha!!!");
                                Logger.logTaiXiu(pl, 4, pl.goldTai, 0);
                            }
                        }
                        for (int i = 0; i < PlayersXiu.size(); i++) {
                            Player pl = this.PlayersXiu.get(i);
                            if (pl != null && Client.gI().getPlayer(pl.name) != null) {
                                Service.getInstance().sendThongBao(pl, "Số hệ thống quay ra\n" + x + " : "
                                        + y + " : " + z + "\n|5|Tổng là : " + tong + "\n(TAM HOA)\n\n|7|Hahaha Nhà cái lụm hết nha!!!");
                                Logger.logTaiXiu(pl, 5, pl.goldXiu, 0);
                            }
                        }
                    }
                    for (int i = 0; i < TaiXiu.gI().PlayersTai.size(); i++) {
                        Player pl = TaiXiu.gI().PlayersTai.get(i);
                        if (pl != null) {
                            pl.goldTai = 0;
                        }
                    }
                    for (int i = 0; i < TaiXiu.gI().PlayersXiu.size(); i++) {
                        Player pl = TaiXiu.gI().PlayersXiu.get(i);
                        if (pl != null) {
                            pl.goldXiu = 0;
                        }
                    }
                    ketquaXiu = false;
                    ketquaTai = false;
                    ketquaTamhoa = false;
                    TaiXiu.gI().goldTai = 0;
                    TaiXiu.gI().goldXiu = 0;
                    TaiXiu.gI().PlayersTai.clear();
                    TaiXiu.gI().PlayersXiu.clear();
                    TaiXiu.gI().lastTimeEnd = System.currentTimeMillis() + 100000;
//                    GirlkunDB.executeUpdate("UPDATE player SET Tai_xiu = JSON_REPLACE(JSON_REPLACE(Tai_xiu, '$[0]', 0), '$[1]', 0)");
                }
                Thread.sleep(500);
            } catch (Exception e) {
            }
        }
    }
}
